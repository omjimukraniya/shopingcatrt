const Parking = require('../models/parking')

exports.parkingpage = async (req, res) => {
    try {
        const loginname = req.session.loginname
        const record = await Parking.find()
        res.render('parking.ejs', { loginname, record })
    } catch (error) {
        console.log(error)
    }
}

exports.parkingform = (req, res) => {
    try {
        const loginname = req.session.loginname
        res.render('parkingform.ejs', { loginname })
    } catch (error) {
        console.log(error)
    }
}


exports.parkingadd = (req, res) => {
    try {
        const { vno, vtype } = req.body
        const vtime = new Date()
        const record = new Parking({ vno: vno, vtype: vtype, vin: vtime })
        record.save()
        //console.log(record)
        res.redirect('/parking')
    } catch (error) {
        console.log(error)
    }
}

exports.parkingupdate = async (req, res) => {
    try {
        const id = req.params.id
        let outTime = new Date()
        const record = await Parking.findById(id)
        let consumedTime = (outTime - record.vin) / (1000 * 60 * 60)
        let amount = null
        if (record.vtype == '2w') {
            amount = consumedTime * 30
        } else if (record.type == '3w') {
            amount = consumedTime * 50
        } else if (record.type == '4w') {
            amount = consumedTime * 80
        } else if (record.type == 'hw') {
            amount = consumedTime * 120
        } else if (record.type == 'lw') {
            amount = consumedTime * 100
        } else {
            amount = consumedTime * 60
        }
        await Parking.findByIdAndUpdate(id, { vout: outTime, amount: Math.round(amount), status: 'OUT' })
        res.redirect('/parking')
    } catch (error) {
        console.log(error)
    }
}

exports.waytoprint = async (req, res) => {
    try {
        const id = req.params.id
        const record = await Parking.findById(id)
        res.render('printpage.ejs', { record })
    } catch (error) {
        console.log(error)
    }
}