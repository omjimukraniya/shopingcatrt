const Reg = require('../models/reg')
const bcrypt = require('bcrypt')


exports.loginpage = (req, res) => {
    res.render('login.ejs', { message: '' })
}


exports.signuppage = (req, res) => {
    try {
        res.render('signup.ejs', { message: '' })
    } catch (error) {
        console.log(error)
    }
}


exports.signup = async (req, res) => {
    try {
        const { us, pass } = req.body
        const usercheck = await Reg.findOne({ username: us })
        const passConvert = await bcrypt.hash(pass, 10)
        if (usercheck == null) {
            const record = new Reg({ username: us, password: passConvert })
            record.save()
            //console.log(record)
            res.render('signup.ejs', { message: `Username ${us} Successfully Registered` })
        } else {
            res.render('signup.ejs', { message: `Username ${us} Already Taken` })
        }
    } catch (error) {
        console.log(error)
    }
}


exports.logincheck = async (req, res) => {
    try {
        const { us, pass } = req.body
        const record = await Reg.findOne({ username: us })
        if (record !== null) {
            const passwordcompare = await bcrypt.compare(pass, record.password)
            if (passwordcompare) {
                req.session.isAuth = true
                req.session.loginname = us
                res.redirect('/parking')
            } else {
                res.render('login.ejs', { message: 'Wrong Credrnatils' })
            }
        } else {
            res.render('login.ejs', { message: 'Wrong Credrnatils' })
        }
    } catch (error) {
        console.log(error)
    }
}



exports.logout = (req, res) => {
    try {
        req.session.destroy()
        res.redirect('/')
    } catch (error) {
        console.log(error)
    }
}