const mongoose=require('mongoose')


const userSchema=mongoose.Schema({
    username:String,
    status:{type:String,default:'Activate'}
})




module.exports=mongoose.model('usermanagement',userSchema)