const router=require('express').Router()
const upload=require('../helpers/multer')
const regc=require('../controllers/regcontroller')
const productc=require('../controllers/productcontroller')
const usermanagementc=require('../controllers/usercontroller')


router.post('/register',regc.register)
router.post('/login',regc.logincheck)
router.post('/addproduct',upload.single('img'),productc.addproducts)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id',upload.single('img'),productc.productupdate)
router.get('/stockproducts',productc.stockproducts)
router.post('/cart',productc.cart)
router.post('/checkout/:username',productc.checkout)





module.exports=router