const Reg = require('../models/reg')
const bcrypt = require('bcrypt')

exports.register = async (req, res) => {
    const { email, password } = req.body
    const convertpass = await bcrypt.hash(password, 10)
    //console.log(convertpass)
    const usercheck = await Reg.findOne({ email: email })
    //console.log(usercheck)
    try {
        if (usercheck == null) {
            const record = new Reg({ email: email, password: convertpass })
            record.save()
            res.json({
                status: 201,
                apiData: record,
                message: `Account ${email} as been successfully created.`
            })
        } else {
            res.json({
                status: 400,
                message: `${email} is already taken.`
            })
        }
    } catch (error) {
        res.json({
            status: 400,
            message: error.message
        })
    }
}


exports.logincheck = async (req, res) => {
    const { email, password } = req.body
    try {
        const record = await Reg.findOne({ email: email })
        if (record !== null) {
            const checkpass = await bcrypt.compare(password, record.password)
            if (checkpass) {
                res.json({
                    status: 200,
                    apiData: record.email
                })
            } else {
                res.json({
                    status: 400,
                    message: "Wrong Password"
                })
            }
        } else {
            res.json({
                status: 400,
                message: "Wrong Email"
            })
        }
    } catch (error) {
        res.json({
            status: 400,
            message: error.message
        })
    }
}