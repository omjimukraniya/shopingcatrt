import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Login from './comp/Login';
import Reg from './comp/Reg';
import Header from './comp/Header';
import { Contextapi } from './Contextapi';
import { useEffect, useState } from 'react';
import Products from './comp/Products';
import Dashboard from './comp/Dashboard';
import Adminproducts from './comp/Adminproducts';
import Adminproductform from './comp/Adminproductform';
import Adminproductupdate from './comp/Adminproductupdate';
import Cart from './comp/Cart';
import Usermanagement from './comp/Usermanagement';

function App() {
  const[cart,setCart]=useState('')
  useEffect(()=>{localStorage.setItem('cart',JSON.stringify(cart))},[cart])
  const[loginname,setLoginname]=useState(localStorage.getItem('loginname'))
  return (
    <Router>
      <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
        <Header />
        <Routes>
          <Route path='/' element={<Login />}></Route>
          <Route path='/reg' element={<Reg />}></Route>
          <Route path='/products' element={<Products/>}></Route>
          <Route path='/dashboard' element={<Dashboard/>}></Route>
          <Route path='/adminproducts' element={<Adminproducts/>}></Route>
          <Route path='/adminnewproduct' element={<Adminproductform/>}></Route>
          <Route path='/adminproductupdate/:id' element={<Adminproductupdate/>}></Route>
          <Route path='/cart' element={<Cart/>}></Route>
          <Route path='/usermanagement' element={<Usermanagement/>}></Route>
        </Routes>
      </Contextapi.Provider>
    </Router>
  );
}

export default App;