import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproducts() {

    const [message, setMessage] = useState('')
    const [products, setProducts] = useState([])

    useEffect(() => {
        fetch('/api/allproducts').then((result) => { return result.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProducts(data.apiData)
            } else {
                setMessage(data.message)
            }
        })
    }, [])



    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9">
                        <h2>Product Management</h2>
                        <p>{message}</p>
                        <Link to='/adminnewproduct'><button className="btn btn-primary form-control">Add New Product</button></Link>
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Product Image</th>
                                    <th>Product Name</th>
                                    <th>Product Description</th>
                                    <th>Product Price</th>
                                    <th>Product Quantity</th>
                                    <th>Product Status</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((result, key) => (
                                    <tr key={result._id}>
                                        <td>{key + 1}</td>
                                        <td><img src={`upload/${result.img}`} style={{width:"80px"}} alt="" /></td>
                                        <td>{result.name}</td>
                                        <td>{result.desc}</td>
                                        <td>{result.price}</td>
                                        <td>{result.qty}</td>
                                        <td>{result.status}</td>
                                        <td><Link to={`/adminproductupdate/${result._id}`}><button className="btn btn-warning">Updata</button></Link></td>
                                        <td><button className="btn btn-danger">Delete</button></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminproducts;