import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Login() {

    const navigate = useNavigate()
    const {setLoginname } = useContext(Contextapi)
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [message, setMessage] = useState('')

    function handleform(e) {
        e.preventDefault()
        const data = { email, password }
        fetch('/api/login', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        }).then((result) => { return result.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                localStorage.setItem('loginname', data.apiData)
                setLoginname(localStorage.getItem('loginname'))
                if (data.apiData === 'admin@gmail.com') {
                    navigate('/dashboard')
                } else {
                    navigate('/products')
                }
            } else {
                setMessage(data.message)
            }
        })
    }

    return (
        <section id="login">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                        <form onSubmit={(e) => { handleform(e) }}>
                            <h2>!! Login Here !!</h2>
                            <p>{message}</p>
                            <label>Username/Email</label>
                            <input type="email" className="form-control"
                                value={email}
                                onChange={(e) => { setEmail(e.target.value) }}
                            />
                            <label>Password</label>
                            <input type="password" className="form-control"
                                value={password}
                                onChange={(e) => { setPassword(e.target.value) }}
                            />
                            <button type="submit" className="form-control btn btn-primary mt-3">Login</button>
                        </form>
                        <Link to='/reg'><button className="btn btn-success form-control mt-4">Create Account</button></Link>
                    </div>
                    <div className="col-md-4"></div>
                </div>
            </div>
        </section>
    );
}

export default Login;