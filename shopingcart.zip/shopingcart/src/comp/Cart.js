import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";
import {useNavigate} from "react-router-dom"

function Cart() {

    const navigate=useNavigate()

    let totalamount = 0
    const { cart, setCart, loginname } = useContext(Contextapi)
    const [message, setmessage] = useState('')
    const [products, setProducts] = useState([])

    useEffect(() => {
        if (!cart.item) {
            return
        }
        fetch('/api/cart', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ids: Object.keys(cart.item) })
        }).then((result) => { return result.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProducts(data.apiData)
            } else {
                setmessage(data.message)
            }
        })
    }, [])

    function handleqty(id) {
        return cart.item[id]
    }

    function handleincrement(e, id, qty) {
        let currentqty = handleqty(id)
        if (currentqty === qty) {
            alert("You have reached to Max Quantity")
            return
        }
        let _cart = { ...cart }
        _cart.item[id] = currentqty + 1
        _cart.totalitems += 1
        setCart(_cart)
    }

    function handledecrement(e, id) {
        let currentqty = handleqty(id)
        if (currentqty === 1) {
            alert("You have reached to Min Quantity")
            return
        }
        let _cart = { ...cart }
        _cart.item[id] = currentqty - 1
        _cart.totalitems -= 1
        setCart(_cart)
    }

    function handleprice(id, price) {
        let tprice = handleqty(id) * price
        totalamount += tprice
        return tprice
    }

    function handlecheckout(e){
        fetch(`/api/checkout/${loginname}`,{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(cart.item)
        })
        setCart('')
        navigate('/products')
    }

    function handleremove(e,id){
        let _cart = { ...cart }
        let currentqty =handleqty(id)

        
    }

    return (
        <section id="mid">
            {products.length !== 0 ?
                <>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <h2 className="mb-5">Cart</h2>
                                <table className="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Product Name</th>
                                            <th>Product Quantity</th>
                                            <th>Product Price</th>
                                            <th>Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {products.map((result, sn) => (
                                            <tr>
                                                <td>{sn + 1}</td>
                                                <td>{result.name}</td>
                                                <td><button className="btn btn-primary me-1" onClick={(e) => { handleincrement(e, result._id, result.qty) }}>+</button><button className="btn btn-info">{handleqty(result._id)}</button><button className="btn btn-primary ms-1" onClick={(e) => { handledecrement(e, result._id) }}>-</button></td>
                                                <td>{handleprice(result._id, result.price)}</td>
                                                <td><button className="btn btn-danger" onClick={(e)=>{handleremove(e, result._id)}}>Remove</button></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colSpan="5">Total Amount Paid: {totalamount}</td>
                                        </tr>
                                        <tr>
                                            <td colSpan="5"><button className="btn btn-success form-control" onClick={(e)=>{handlecheckout(e)}}>Check Out</button></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div >
                </>
                :
                <>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <img style={{ width: '800px' }} src="emptycart.jpg" />
                            </div>
                        </div>
                    </div>
                </>
            }

        </section>
    );
}

export default Cart;