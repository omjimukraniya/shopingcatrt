import { useContext } from "react";
import { Contextapi } from "../Contextapi";

function Productstr(props) {
    const { cart, setCart } = useContext(Contextapi)
    const { product } = props

    function handlecart(e, productid) {
        //console.log(productid)
        let _cart = { ...cart }
        if (!_cart.item) {
            _cart.item = {}

        }
        if (!_cart.item[productid]) {
            _cart.item[productid] = 1
        } else {
            _cart.item[productid] += 1
        }

        if (!_cart.totalitems) {
            _cart.totalitems = 1
        } else {
            _cart.totalitems += 1
        }
        setCart(_cart)
        //console.log(cart)
    }

    return (

        <div className="col-md-3">
            <div className="card mt-4" style={{ width: '18rem' }}>
                <img  src={`upload/${product.img}`} style={{width:"80px"}}  className="card-img-top mt-2" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-text">{product.desc}</p>
                    <p className="card-text">Price Rs. {product.price}</p>
                    <button className="btn btn-primary me-2" onClick={(e) => { handlecart(e, product._id) }}>Add to Cart</button>
                    <button className="btn btn-success">Details</button>
                </div>
            </div>
        </div>


    );
}

export default Productstr;